<?php
/**
 * FoodSaver Cleanup & Install Script
 * Upload this file to your InfinityFree htdocs/ root.
 * Visit: https://foodsaver.infinityfreeapp.com/cleanup.php?key=fs2025clean
 * This script deletes all old HTML files and sets up .htaccess redirects.
 * It SELF-DELETES after running successfully.
 */

// ── Secret key so only you can run this ──
define('CLEANUP_KEY', 'fs2025clean');

if (($_GET['key'] ?? '') !== CLEANUP_KEY) {
    http_response_code(403);
    die('Access denied. Add ?key=fs2025clean to the URL.');
}

$root    = rtrim($_SERVER['DOCUMENT_ROOT'], '/\\');
$deleted = [];
$failed  = [];
$skipped = [];

// ── 1. Delete all .html files in root ──
$html_files = glob($root . '/*.html');
if ($html_files === false) $html_files = [];
foreach ($html_files as $file) {
    if (@unlink($file)) {
        $deleted[] = basename($file);
    } else {
        $failed[] = basename($file);
    }
}

// ── 2. Delete old CSS / JS / images folders from previous system ──
$old_dirs = ['css', 'js', 'images', 'img', 'fonts', 'customer'];
foreach ($old_dirs as $dir) {
    $path = $root . '/' . $dir;
    if (is_dir($path)) {
        $result = deleteDir($path);
        if ($result) {
            $deleted[] = $dir . '/ (folder)';
        } else {
            $failed[] = $dir . '/ (folder)';
        }
    } else {
        $skipped[] = $dir . '/ (not found)';
    }
}

// ── 3. Write .htaccess if missing ──
$htaccess = $root . '/.htaccess';
$htaccess_ok = false;
if (!file_exists($htaccess)) {
    $content = <<<'HTACCESS'
Options -Indexes -MultiViews
RewriteEngine On
RewriteRule ^userBrowseFood\.html$    /browse_listings.php   [R=301,L]
RewriteRule ^userViewFood\.html$      /browse_listings.php   [R=301,L]
RewriteRule ^userHomePage\.html$      /index.php             [R=301,L]
RewriteRule ^loginPage\.html$         /auth/login.php        [R=301,L]
RewriteRule ^registerPage\.html$      /auth/register.php     [R=301,L]
RewriteRule ^businessDashboard\.html$ /business/dashboard.php [R=301,L]
RewriteRule \.html$                   /                      [R=301,L]
ErrorDocument 404 /404.php
HTACCESS;
    $htaccess_ok = (file_put_contents($htaccess, $content) !== false);
} else {
    $htaccess_ok = true; // already there
}

// ── 4. Self-delete this script ──
$self = __FILE__;

function deleteDir(string $dir): bool {
    if (!is_dir($dir)) return false;
    $items = array_diff(scandir($dir), ['.', '..']);
    foreach ($items as $item) {
        $path = $dir . DIRECTORY_SEPARATOR . $item;
        if (is_dir($path)) {
            deleteDir($path);
        } else {
            @unlink($path);
        }
    }
    return @rmdir($dir);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>FoodSaver — Cleanup Complete</title>
<style>
  body { font-family: system-ui, sans-serif; max-width: 700px; margin: 40px auto; padding: 0 20px; background: #f4faf6; color: #1a1a2e; }
  h1 { color: #1a6b3a; font-size: 1.6rem; }
  .ok  { background: #e8f5ee; border: 1px solid #c3dfc9; border-radius: 8px; padding: 12px 16px; margin: 8px 0; }
  .bad { background: #fce8e8; border: 1px solid #f5c2c7; border-radius: 8px; padding: 12px 16px; margin: 8px 0; }
  .info{ background: #fff8e1; border: 1px solid #ffe082; border-radius: 8px; padding: 12px 16px; margin: 8px 0; }
  code { font-family: monospace; font-size: 0.85em; background: #eee; padding: 2px 6px; border-radius: 4px; }
  ul { margin: 6px 0; padding-left: 20px; }
</style>
</head>
<body>
<h1>🍱 FoodSaver Cleanup</h1>

<?php if (!empty($deleted)): ?>
<div class="ok">
  <strong>✅ Deleted (<?= count($deleted) ?> items):</strong>
  <ul><?php foreach ($deleted as $d): ?><li><code><?= htmlspecialchars($d) ?></code></li><?php endforeach; ?></ul>
</div>
<?php endif; ?>

<?php if (!empty($failed)): ?>
<div class="bad">
  <strong>❌ Could not delete (check FTP permissions):</strong>
  <ul><?php foreach ($failed as $f): ?><li><code><?= htmlspecialchars($f) ?></code></li><?php endforeach; ?></ul>
</div>
<?php endif; ?>

<?php if (!empty($skipped)): ?>
<div class="info">
  <strong>ℹ️ Already gone (skipped):</strong>
  <ul><?php foreach ($skipped as $s): ?><li><code><?= htmlspecialchars($s) ?></code></li><?php endforeach; ?></ul>
</div>
<?php endif; ?>

<div class="<?= $htaccess_ok ? 'ok' : 'bad' ?>">
  <?= $htaccess_ok ? '✅ .htaccess is in place — old HTML URLs will redirect.' : '❌ Could not write .htaccess — upload it manually.' ?>
</div>

<div class="info">
  <strong>⚠️ Next steps:</strong>
  <ol>
    <li>Upload all the new PHP files from your GitHub repo to <code>htdocs/</code></li>
    <li>Make sure <code>config/db.php</code> exists with your InfinityFree MySQL credentials</li>
    <li>Visit <a href="/index.php">/index.php</a> — your new FoodSaver platform should load</li>
    <li>This cleanup script will now self-delete for security.</li>
  </ol>
</div>

<?php
// Self-delete
@unlink($self);
echo '<p style="font-size:0.8em;color:#888;">cleanup.php has been deleted from the server. ✓</p>';
?>
</body>
</html>
