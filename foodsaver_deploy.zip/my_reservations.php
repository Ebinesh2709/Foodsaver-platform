<?php
session_start();

// Role guard
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'customer') {
    header('Location: auth/login.php');
    exit;
}

define('APP_RUNNING', true);
require_once 'config/db.php';
require_once 'includes/csrf_helper.php';

$user_id = (int)$_SESSION['user_id'];

$stmt = $pdo->prepare(
    'SELECT r.id, r.status, r.created_at,
            fl.title, fl.category, fl.discounted_price,
            fl.pickup_end, fl.urgency_score, fl.ai_summary,
            b.business_name, b.area
     FROM reservations r
     JOIN food_listings fl ON r.listing_id = fl.id
     JOIN businesses b ON fl.business_id = b.id
     WHERE r.user_id = ?
     ORDER BY r.created_at DESC'
);
$stmt->execute([$user_id]);
$reservations = $stmt->fetchAll();

$page_title  = 'My Reservations';
$active_page = 'reservations';
$css_prefix  = '';
require_once 'includes/header.php';
?>

<div class="fs-page-header">
    <div class="container">
        <h1><i class="bi bi-bag-check me-2"></i>My Reservations</h1>
        <p>Track and manage your current food reservations</p>
    </div>
</div>

<div class="container pb-5">

    <?php if (isset($_GET['reserved']) && $_GET['reserved'] == '1'): ?>
        <div class="fs-alert-success mb-4">
            <i class="bi bi-check-circle me-2"></i>Reservation created! The business will confirm it shortly.
        </div>
    <?php endif; ?>

    <?php if (empty($reservations)): ?>
        <div class="fs-empty">
            <span class="empty-icon">📅</span>
            <h2>No reservations yet</h2>
            <p>Browse available food listings and reserve something delicious before it expires!</p>
            <a href="browse_listings.php" class="btn btn-fs-primary px-4">Browse Listings</a>
        </div>
    <?php else: ?>
        <div class="row g-3">
        <?php foreach ($reservations as $res): ?>
            <?php
            $status = $res['status'];
            $badge_html = match($status) {
                'pending'   => '<span class="status-badge status-pending">Pending</span>',
                'confirmed' => '<span class="status-badge status-confirmed">Confirmed</span>',
                'collected' => '<span class="status-badge status-collected">Collected</span>',
                'cancelled' => '<span class="status-badge status-cancelled">Cancelled</span>',
                default     => '<span class="status-badge status-collected">' . htmlspecialchars($status, ENT_QUOTES, 'UTF-8') . '</span>',
            };
            ?>
            <div class="col-md-6">
                <div class="fs-card" style="padding:1.4rem 1.5rem;">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <h2 class="h6 fw-bold mb-0" style="font-size:1rem; max-width:70%;"><?= htmlspecialchars($res['title'], ENT_QUOTES, 'UTF-8') ?></h2>
                        <?= $badge_html ?>
                    </div>

                    <?php if ($status === 'confirmed'): ?>
                        <p style="font-size:0.82rem; color:var(--fs-green); font-weight:700; margin-bottom:0.5rem;">
                            <i class="bi bi-bag-check me-1"></i>Ready for pickup!
                        </p>
                    <?php endif; ?>

                    <?php if (!empty($res['ai_summary'])): ?>
                        <p style="font-size:0.78rem; font-style:italic; color:var(--fs-green-mid); border-left:2px solid var(--fs-green-light); padding-left:0.6rem; margin-bottom:0.5rem;"><?= htmlspecialchars($res['ai_summary'], ENT_QUOTES, 'UTF-8') ?></p>
                    <?php endif; ?>

                    <p style="font-size:0.8rem; color:var(--fs-text-muted); margin-bottom:0.3rem;">
                        <i class="bi bi-shop me-1"></i><?= htmlspecialchars($res['business_name'], ENT_QUOTES, 'UTF-8') ?>
                        <?php if ($res['area']): ?> &middot; <?= htmlspecialchars($res['area'], ENT_QUOTES, 'UTF-8') ?><?php endif; ?>
                    </p>
                    <p style="font-size:0.8rem; color:var(--fs-text-muted); margin-bottom:0.3rem;">
                        <i class="bi bi-tag me-1"></i><?= htmlspecialchars(ucfirst($res['category']), ENT_QUOTES, 'UTF-8') ?>
                        &nbsp;&middot;&nbsp;
                        <?= get_urgency_badge_html($res['urgency_score']) ?>
                    </p>
                    <p style="font-size:0.9rem; font-weight:800; color:var(--fs-green); margin-bottom:0.3rem;">
                        LKR <?= htmlspecialchars(number_format((float)$res['discounted_price'], 2), ENT_QUOTES, 'UTF-8') ?>
                    </p>
                    <p style="font-size:0.78rem; color:var(--fs-text-muted); margin-bottom:0.3rem;">
                        <i class="bi bi-clock me-1"></i>Pickup by: <strong><?= htmlspecialchars(date('D d M, g:i A', strtotime($res['pickup_end'])), ENT_QUOTES, 'UTF-8') ?></strong>
                    </p>
                    <p style="font-size:0.75rem; color:var(--fs-text-muted); margin-bottom:0.75rem;">
                        Reserved: <?= htmlspecialchars(date('d M Y, H:i', strtotime($res['created_at'])), ENT_QUOTES, 'UTF-8') ?>
                    </p>

                    <?php if ($status === 'pending'): ?>
                        <form method="post" action="cancel_reservation.php"
                              onsubmit="return confirm('Cancel this reservation? The item will become available again.');">
                            <input type="hidden" name="csrf_token" value="<?= generate_csrf_token() ?>">
                            <input type="hidden" name="reservation_id" value="<?= (int)$res['id'] ?>">
                            <button type="submit" id="btn-cancel-<?= (int)$res['id'] ?>" class="btn btn-fs-danger btn-sm">
                                <i class="bi bi-x-circle me-1"></i>Cancel Reservation
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php require_once 'includes/footer.php'; ?>
